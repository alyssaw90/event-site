﻿/// <reference path="../App.js" />

(function () {
    "use strict";

    // Color class (HSV)
    function ColorHSV()
    {
        this.h = 0;
        this.s = 0;
        this.v = 0;

        // Convert from ColorRGB
        this.ConvertFromColorRGB = function (color)
        {
            // Find min and max
            var min	= Math.min(color.red, color.green, color.blue);
            var max = Math.max(color.red, color.green, color.blue);

            // Set value
            this.v = max;

            // Set saturation
            if (max != 0.0) 
            {
                this.s = (max - min) / max;
            }
            else 
            {
                this.h = 0.0;
                this.s = 0.0;
                return;
            }

            // Delta
            var delta = max - min;

            // The color has no hue (a shade of gray)
            if (Math.abs(delta) < 0.000001)
            {
                this.h = 0.0;
                return;
            }

            // Regular hue values
            if (color.red == max) 
            {
                this.h = 0.0 + (color.green - color.blue) / delta;
            }
            else if (color.green == max) 
            {
                this.h = 2.0 + (color.blue - color.red) / delta;
            }
            else if (color.blue == max) 
            {
               this.h = 4.0 + (color.red - color.green) / delta;
            }

            this.h *= 60.0;

            // Roll over
            if (this.h < 0.0) 
            {
                this.h += 360.0;
            }
        };

        // Convert to ColorRGB
        this.ConvertToColorRGB = function ()
        {
            // RGB Color
            var result = new ColorRGB();

            // Get local copies as we adjust some of the values
            var h = this.h;
            var s = this.s;
            var v = this.v;
	
            // Make sure it is below 360
            if (h >= 360.0) 
            {
                h = 359.5;
            }

            // Precompute some values
            h           /= 60.0;
            var index   = Math.floor(h);
            var f       = h - index;
            var p       = v * (1.0 - s);
            var q       = v * (1.0 - s * f);
            var t       = v * (1.0 - s * (1.0 - f));

            switch (index) 
            {
                case 0:
                    result.red = v;
                    result.green = t;
                    result.blue = p;
                    break;	

                case 1:
                    result.red = q;
                    result.green = v;
                    result.blue = p;
                    break;

                case 2:
                    result.red = p;
                    result.green = v;
                    result.blue = t;
                    break;

                case 3:
                    result.red = p;
                    result.green = q;
                    result.blue = v;
                    break;

                case 4:
                    result.red = t;
                    result.green = p;
                    result.blue = v;
                    break;

                case 5:
                    result.red = v;
                    result.green = p;
                    result.blue = q;
                    break;
            }

            // Done
            return result;
        };
    }

    // Color class (RGB)
    function ColorRGB()
    {
        this.red = 0;
        this.green = 0;
        this.blue = 0;

        // Setter
        this.SetColor = function (_red, _green, _blue)
        {
            this.red = _red;
            this.green = _green;
            this.blue = _blue;
        };

        // HSV conversion
        this.GetColorHSV = function()
        {
            // Create new HSV color
            var hsvColor = new ColorHSV();

            // Convert
            hsvColor.ConvertFromColorRGB(this);

            // Done
            return hsvColor;
        };

        // Function to add two colors (first represented by this)
        this.AddColor = function(color)
        {
            // Create new color
            var result = new ColorRGB();

            // Add this color to the parameter
            result.SetColor(this.red + color.red, this.green + color.green, this.blue + color.blue);

            // Done
            return result;
        };

        // Function to interpolate two colors (first represented by this)
        this.InterpolateColors = function(color, ratio, colorSpace)
        {
            // Create new color
            var result = new ColorRGB();

            // RGB space
            if (colorSpace == "rgb")
            {
                result.SetColor(this.red * (1.0 - ratio) + color.red * ratio,
                                this.green * (1.0 - ratio) + color.green * ratio,
                                this.blue * (1.0 - ratio) + color.blue * ratio);
            }
            // HSV space
            else
            {
                // Create the coressponding HSV colors
                var hsvResult = new ColorHSV();
                var hsvColor1 = this.GetColorHSV();
                var hsvColor2 = color.GetColorHSV();
               
                // Interpolate
                hsvResult.h = hsvColor1.h * (1.0 - ratio) + hsvColor2.h * ratio;
                hsvResult.s = hsvColor1.s * (1.0 - ratio) + hsvColor2.s * ratio;
                hsvResult.v = hsvColor1.v * (1.0 - ratio) + hsvColor2.v * ratio;

                // Convert back to RGB
                result = hsvResult.ConvertToColorRGB();
            }

            // Done
            return result;
        };

        // Function to convert decimal number into 2 digit hex number
        this.ConvertDecimalToHex = function(decimalValue)
        {
            // Create hex value string (make sure it is integer)
            var hexValue = Number(Math.floor(decimalValue)).toString(16);

            // Add padding (required since colors must use exactly two characters)
            while (hexValue.length < 2)
            {
                hexValue = "0" + hexValue;
            }

            // Done
            return hexValue;
        };

        // Function to convert string representing hex value into regular integer
        this.ConvertHexToDecimal = function (hexString)
        {
            return parseInt(hexString, 16);
        };

        // Function to convert color into HTML string color value
        this.ConvertToHTMLColor = function ()
        {
            // Add three colors into one string
            var stringColor = this.ConvertDecimalToHex(this.red) + this.ConvertDecimalToHex(this.green) + this.ConvertDecimalToHex(this.blue);

            // Done
            return stringColor;
        };

        // Function to convert color from HTML string ("#abcdef")
        this.ConvertFromHTMLColor = function (htmlColor)
        {
            // Extract substring for each color component
            var red     = String(htmlColor).substring(1, 3);
            var green   = String(htmlColor).substring(3, 5);
            var blue    = String(htmlColor).substring(5, 7);

            // Convert to number
            this.red    = this.ConvertHexToDecimal(red);
            this.green  = this.ConvertHexToDecimal(green);
            this.blue   = this.ConvertHexToDecimal(blue);
        };
    }

    // The initialize function must be run each time a new page is loaded
    Office.initialize = function (reason)
    {
        $(document).ready(function ()
        {
			// Initalize the app
            app.initialize();

            // Detect incompatible Excel 2013
            if (Office.context.requirements.isSetSupported('ExcelApi', 1.1) == false)
            {
                $(".errorMessage").show();
                $(".padding").hide();

                return;
            }

            // Set the default value for mode to matrix
            $("#modeType").prop("selectedIndex", 3);

            // Logic for hiding and adjusting UI based on Type
            $("#uniform").click(function ()
            {
                $(".cpButton1st").show();
                $(".cpButton2nd, .cpButton3rd, .cpButton4th").hide();
                $(".rowInterpolation").hide();
                $(".rowColorSpace").hide();
            });
        
            $("#vertical").click(function ()
            {
                $(".cpButton1st, .cpButton3rd").show();
                $(".cpButton2nd, .cpButton4th").hide();
                $(".rowInterpolation").show();
                $(".rowColorSpace").show();
            });

            $("#horizontal").click(function ()
            {
                $(".cpButton1st, .cpButton2nd").show();
                $(".cpButton3rd, .cpButton4th").hide();
                $(".rowInterpolation").show();
                $(".rowColorSpace").show();
            });

            $("#matrix").click(function ()
            {
                $(".cpButton1st, .cpButton2nd, .cpButton3rd, .cpButton4th").show();
                $(".rowInterpolation").show();
                $(".rowColorSpace").show();
            });

            // Logic for hiding and adjusting UI based on pattern type
            $(".rowPatternContrast").hide();
            $(".rowPatternWaves").hide();

            $("#patternTypeNone").click(function ()
            {
                $(".rowPatternContrast, .rowPatternWaves").hide();
            });

            $("#patternTypeInterlaced").click(function ()
            {
                $(".rowPatternContrast").show();
                $(".rowPatternWaves").hide();
            });

            $("#patternTypeWaves").click(function ()
            {
                $(".rowPatternContrast, .rowPatternWaves").show();
            });
                       
            // Instantiate the colorpicker class on the 4 controls
            $('#cpButton11').colorpicker(
            {
                defaultPalette: 'web',
                history: false
            });

            $('#cpButton12').colorpicker(
            {
                defaultPalette: 'web',
                history: false
            });

            $('#cpButton21').colorpicker(
            {
                defaultPalette: 'web',
                history: false
            });

            $('#cpButton22').colorpicker(
            {
                defaultPalette: 'web',
                history: false
            });

            // Validation for pattern contrast
            $('#patternContrast').change(function (event)
            {
                var contrastString = $("#patternContrast").val();
                var contrastValue = parseFloat(contrastString, 10);

                // Not a number - reset to default 10%
                if (isNaN(contrastValue))
                {
                    document.getElementById("patternContrast").value = "10";
                }
                // Number - validate between 0 and 100
                else
                {
                    if (contrastValue < 0)
                    {
                        contrastValue = 0;
                    }
                    else if (contrastValue > 100)
                    {
                        contrastValue = 100;
                    }

                    document.getElementById("patternContrast").value = Number(contrastValue).toString(10);
                }
            });

            // Validation for pattern waves
            $('#patternWaves').change(function (event)
            {
                var wavesString = $("#patternWaves").val();
                var wavesValue = parseFloat(wavesString, 10);

                // Not a number - reset to default 4
                if (isNaN(wavesValue))
                {
                    document.getElementById("patternWaves").value = "4";
                }
                // Number - validate between 1 and 100
                else
                {
                    if (wavesValue < 1)
                    {
                        wavesValue = 1;
                    }
                    else if (wavesValue > 100)
                    {
                        wavesValue = 100;
                    }

                    document.getElementById("patternWaves").value = Number(wavesValue).toString(10);
                }
            });

            // Main button handler
            $('#colorize-selection').click(function (event)
            {
                Excel.run(function (ctx)
                {
                    // Get selection
                    var selectedRange = ctx.workbook.getSelectedRange();
                    selectedRange.load();

                    // Retrieve UI parameters 
                    var htmlColor11 = $("#cpButton11").val();
                    var htmlColor12 = $("#cpButton12").val();
                    var htmlColor21 = $("#cpButton21").val();
                    var htmlColor22 = $("#cpButton22").val();

                    var color11 = new ColorRGB();
                    var color12 = new ColorRGB();
                    var color21 = new ColorRGB();
                    var color22 = new ColorRGB();

                    color11.ConvertFromHTMLColor(htmlColor11);
                    color12.ConvertFromHTMLColor(htmlColor12);
                    color21.ConvertFromHTMLColor(htmlColor21);
                    color22.ConvertFromHTMLColor(htmlColor22);

                    var modeType            = $("#modeType").val();
                    var interpolationType   = $("#interpolationType").val();
                    var colorSpaceType      = $("#colorSpaceType").val();
                    var patternType         = $("#patternType").val();
                    var patternContrastStr  = $("#patternContrast").val();
                    var patternWavesStr     = $("#patternWaves").val();

                    var patternContrast     = parseFloat(patternContrastStr, 10);
                    var patternWaves        = parseFloat(patternWavesStr, 10);

                    // Start the async batch process
                    return ctx.sync()

                        // Colorize the selected range after syncing
                        .then(function ()
                        {
                            // Preallocate the color variables
                            var cellColor   = new ColorRGB();
                            var cellLeft    = new ColorRGB();
                            var cellRight   = new ColorRGB();
                            var hsvColor    = new ColorHSV();

                            // Iterate over all our selection region
                            for (var rowIndex = 0; rowIndex < selectedRange.rowCount; rowIndex++)
                            {
                                for (var columnIndex = 0; columnIndex < selectedRange.columnCount; columnIndex++)
                                {
                                    // Compute local ratios
                                    var ratioVertical   = selectedRange.rowCount > 0 ? rowIndex / (selectedRange.rowCount - 1) : 0.0;
                                    var ratioHorizontal = selectedRange.columnCount > 0 ? columnIndex / (selectedRange.columnCount - 1) : 0.0;

                                    // Compute interpolation factors
                                    var factorVertical   = ComputeInterpolationFactor(interpolationType, ratioVertical);
                                    var factorHorizontal = ComputeInterpolationFactor(interpolationType, ratioHorizontal);

                                    // Get local cell
                                    var localCell = selectedRange.getCell(rowIndex, columnIndex);

                                    // Compute color based on the ui parameters
                                    switch (modeType)
                                    {
                                        // Uniform
                                        case "uniform":
                                            {
                                                cellColor = color11;
                                            }
                                            break;

                                        // Vertical
                                        case "vertical":
                                            {
                                                cellColor = color11.InterpolateColors(color21, factorVertical, colorSpaceType);
                                            }
                                            break;

                                        // Horizontal
                                        case "horizontal":
                                            {
                                                cellColor = color11.InterpolateColors(color12, factorHorizontal, colorSpaceType);
                                            }
                                            break;

                                        // Matrix
                                        case "matrix":
                                            {
                                                cellLeft  = color11.InterpolateColors(color21, factorVertical, colorSpaceType);
                                                cellRight = color12.InterpolateColors(color22, factorVertical, colorSpaceType);
                                                cellColor = cellLeft.InterpolateColors(cellRight, factorHorizontal, colorSpaceType);
                                            }
                                            break;
                                    }

                                    // Apply pattern
                                    if ((patternType == "interlaced") || (patternType == "waves"))
                                    {
                                        // Convert to HSV
                                        hsvColor.ConvertFromColorRGB(cellColor);

                                        // Interlaced
                                        if (patternType == "interlaced")
                                        {
                                            if (rowIndex % 2)
                                            {
                                                hsvColor.v *= (1.0 - (patternContrast * 0.01)); 
                                            }
                                        }

                                        // Waves
                                        if (patternType == "waves")
                                        {
                                            hsvColor.v *= 1.0 - (patternContrast - Math.cos(ratioVertical * Math.PI * 2.0 * patternWaves) * patternContrast) * 0.005;
                                        }

                                        // Convert back to RGB
                                        cellColor = hsvColor.ConvertToColorRGB();
                                    }

                                    // Set cell color
                                    localCell.format.fill.color = cellColor.ConvertToHTMLColor();
                                }
                            }
                        })
                        // Final sync
                        .then(ctx.sync)
                    
                })
                // Catch any exceptions
                .catch(function (error)
                {
                    // Show the error info
                    console.log("Error: " + error);
                    if (error instanceof OfficeExtension.Error)
                    {
                        console.log("Debug info: " + JSON.stringify(error.debugInfo));
                    }
                });
            }); 
        });

        // Function to compute interpolation factor based on type
        function ComputeInterpolationFactor(type, value)
        {
            switch (type)
            {
                case "smooth":
                    return (1.0 - Math.cos(Math.PI * value)) * 0.5;

                case "expUp":
                    return (1.0 - ((1.0 - (2.0 - Math.exp(1.0 - value * value))) / (Math.E - 1.0)));

                case "expDown":
                    return (1.0 - (2.0 - Math.exp(value * value))) / (Math.E - 1.0);
            }

            return value;
        }
    };

})();